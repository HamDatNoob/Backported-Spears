package com.notunanancyowen.neoforge;

import com.notunanancyowen.SpearsClient;
import com.notunanancyowen.components.PiercingWeapon;
import com.notunanancyowen.packets.PlayerStabC2SPacket;
import com.notunanancyowen.packets.TriggerStabEffectsC2SPacket;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemGroup.StackVisibility;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;

import com.notunanancyowen.Spears;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@Mod(Spears.MOD_ID)
public final class SpearsNeoForge {
    public SpearsNeoForge(IEventBus modEventBus, ModContainer modContainer) {
        // Run our common setup.
        Spears.init();
        Spears.hasBetterCombat = ModList.get().isLoaded("bettercombat");
        NeoForge.EVENT_BUS.register(this);
        modEventBus.addListener(this::buildContents);
        modEventBus.addListener(this::registerPayloads);
        modContainer.registerConfig(ModConfig.Type.COMMON, SpearsConfig.SPEC);
    }
    private void buildContents(final BuildCreativeModeTabContentsEvent itemGroup) {
        if(itemGroup.getTabKey() == ItemGroups.COMBAT) {
            itemGroup.insertAfter(Items.NETHERITE_SWORD.getDefaultStack(), Spears.WOODEN_SPEAR.getDefaultStack(), StackVisibility.PARENT_AND_SEARCH_TABS);
            itemGroup.insertAfter(Spears.WOODEN_SPEAR.getDefaultStack(), Spears.STONE_SPEAR.getDefaultStack(), StackVisibility.PARENT_AND_SEARCH_TABS);
            itemGroup.insertAfter(Spears.STONE_SPEAR.getDefaultStack(), Spears.IRON_SPEAR.getDefaultStack(), StackVisibility.PARENT_AND_SEARCH_TABS);
            itemGroup.insertAfter(Spears.IRON_SPEAR.getDefaultStack(), Spears.GOLDEN_SPEAR.getDefaultStack(), StackVisibility.PARENT_AND_SEARCH_TABS);
            itemGroup.insertAfter(Spears.GOLDEN_SPEAR.getDefaultStack(), Spears.DIAMOND_SPEAR.getDefaultStack(), StackVisibility.PARENT_AND_SEARCH_TABS);
            itemGroup.insertAfter(Spears.DIAMOND_SPEAR.getDefaultStack(), Spears.NETHERITE_SPEAR.getDefaultStack(), StackVisibility.PARENT_AND_SEARCH_TABS);
        }
    }
    private void registerPayloads(final RegisterPayloadHandlersEvent event) {
        final PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(
                PlayerStabC2SPacket.ID,
                PlayerStabC2SPacket.PACKET_CODEC,
                (packet, context) -> {
                    var p = packet.getEntity(context.player().getWorld());
                    if(p instanceof ServerPlayerEntity sp) {
                        if(sp.getMainHandStack().get(Spears.PIERCING_WEAPON) instanceof PiercingWeapon pw) pw.stab(sp, EquipmentSlot.MAINHAND);
                        sp.resetLastAttackedTicks();
                    }
                });
        registrar.playToServer(
                TriggerStabEffectsC2SPacket.ID,
                TriggerStabEffectsC2SPacket.PACKET_CODEC,
                (packet, context) -> {
                    if(packet.toggle() && context.player() instanceof ServerPlayerEntity s) packet.trigger(s);
                });
    }
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
    }
    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @EventBusSubscriber(modid = Spears.MOD_ID, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent public static void onClientSetup(FMLClientSetupEvent event) {
            SpearsClient.sendPacketUniversal = (payload) -> {
                PacketDistributor.sendToServer(payload);
                return true;
            };
        }
    }
}
